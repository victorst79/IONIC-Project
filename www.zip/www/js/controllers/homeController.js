angular.module('starter')

.controller( 'homeCtrl' , function($scope){
	$scope.search = {
		card: ''
	}
} );

	